public interface Busqueda {

    String busqueda(String fechaSalida, String fechaRegreso, String origen, String destino);

}
